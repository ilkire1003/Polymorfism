/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openjfx.heapsort;

import java.util.ArrayList;

public class Animal {
    
    //Variabler
    private int Animal_ID;
    private String Name;
    private String Food;
    private String Species;
    private int Keeper_ID;
    private int Ammount;
    private float Age;            
    private ArrayList<Keeper> AnimalKeeper = new ArrayList<Keeper>();
    
    
    
    //Constructor for klassen user
    public Animal()
    {}
    
    public Animal(ArrayList<Keeper> _AnimalKeeper){
        AnimalKeeper = _AnimalKeeper;
    }
    
    public Animal(int _Animal_ID, int _Keeper_ID, String _Name, String _Food, String _Species, float _Age, int _Ammount) {
        Animal_ID= _Animal_ID;
        Name= _Name;
        Food= _Food;
        Age=_Age;
        Species=_Species;
        Keeper_ID=_Keeper_ID;
        Ammount=_Ammount;
        Age=_Age;
        
        
        
    }
    
   
    
    public int getAnimalID() {
        return Animal_ID;
    }

    public void setAnimalID(int _Animal_ID) {
        this.Animal_ID = _Animal_ID;
    }

    public String getName() {
        return Name;
    }

    public void setFirstName(String _Name) {
        this.Name = _Name;
    }

    public String getLogToken() {
        return Food;
    }

    public void setLogToken(String _Food) {
        this.Food = _Food;
    }

    public void addKeeper(Keeper newKeeper) {
        AnimalKeeper.add(newKeeper);
    }
    
    public void setAnimalKeeper(ArrayList<Keeper> AnimalKeeper){
        this.AnimalKeeper = AnimalKeeper;
    }
    
    public ArrayList<Keeper> getKeeper(){
        return AnimalKeeper;
    }
}



