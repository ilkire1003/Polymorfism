package org.openjfx.heapsort;

import java.io.IOException;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class PrimaryController {
   
    
    
    
    @FXML
    private Button primaryButton;
    
    @FXML
    private void handleButtonAction(ActionEvent event)throws SQLException, Exception{
    System.out.println("aaaaaaa");
    
    }
    
    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }
}
