package org.openjfx.heapsort;

import java.sql.*;
import java.util.ArrayList;


public class Metoder {
  private final String connectionString = "jdbc:sqlite:src/heaplist.db";
    
    
    ////////////////Hent alle brugere fra people tabellen////////////////
    public ArrayList<Animal> getAllAnimal() throws SQLException, Exception {
        
        ArrayList<Animal> allAnimals = new ArrayList<>();
        
        Connection conn = null;
        Class.forName("org.sqlite.JDBC");
        
        //Skaber forbindelse til databasen
        try {          
          conn = DriverManager.getConnection(connectionString);
        } 
        
        //Fejlhåndtering
        catch ( SQLException e ) {
          System.out.println("DB Error: " + e.getMessage());
        }
        
        //Henter alle brugere fra databasen
        try{ 
            Statement stat = conn.createStatement();   
            
            //Læser databasen
            ResultSet rs = stat.executeQuery("select Animal_ID, Keeper_ID, Name, Age, Ammount, Food, Species from Animals;");
            
            //Henter dataen fra databasen
            while (rs.next()) {
                //int _Animal_ID, int _Keeper_ID, String _Name, String _Food, String _Species, float _Age, int _Ammount
                allAnimals.add(new Animal(Integer.parseInt(rs.getString("Animal_ID")), Integer.parseInt(rs.getString("Keeper_ID")), rs.getString("Name"), rs.getString("Food"), rs.getString("Species"), Float.parseFloat("Age"), Integer.parseInt("Ammount")));
            }
            rs.close();
        }
        
        //Fejlhåndtering
        catch ( SQLException e ) {
            System.out.println("DB Error: " + e.getMessage());
        }
        
        //Lukker forbindelsen til databasen
        conn.close();
        
        //Returnerer alle brugere
        return allAnimals;
    }
     
   
     
    /////////////Opretter brugere i databasen////////////////////
    public void createAnimal(Animal u)throws SQLException, Exception{
        Connection conn = null;
        Class.forName("org.sqlite.JDBC");
        String sql;
        
        //Skaber forbindelse til databasen
        try {          
          conn = DriverManager.getConnection(connectionString);
        }
        
        //Fejlhåndtering
        catch ( SQLException e ) {
          System.out.println("DB Error: " + e.getMessage());
        }
        
        //Skaber ny bruger i databasen
        sql = "INSERT INTO Animals(Name,logtoken) VALUES('" + u.getName() + "','" + u.getLogToken() + "');";
       
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }   
    }
    
        //Henter alle Keepers i databasen
    public ArrayList<Keeper> getAllKeeper() throws SQLException, Exception {
        
        ArrayList<Keeper> allKeeper = new ArrayList<>();
        
        Connection conn = null;
        Class.forName("org.sqlite.JDBC");
        
        //Skaber forbindelse til databasen
        try {          
          conn = DriverManager.getConnection(connectionString);
        } 
        
        //Fejlhåndtering
        catch ( SQLException e ) {
          System.out.println("DB Error: " + e.getMessage());
        }
        
        try{ 
            Statement stat = conn.createStatement();   
            
            //Læser databasen
            ResultSet rs = stat.executeQuery("select Keeper_ID, Animal_ID, content from Keeper;");
            
            //Henter dataen fra databasen
            while (rs.next()) {
                allKeeper.add(new Keeper(Integer.parseInt(rs.getString("Keeper_ID")),Integer.parseInt(rs.getString("Animal_ID"))));            }
            rs.close();
        }
        catch ( SQLException e ) {

            System.out.println("DB Error: " + e.getMessage());
        }
        conn.close();
    
        return allKeeper;
    }
    
    //////////////////Laver Keeperr//////////////////
    public void createKeeper(Keeper f)throws SQLException, Exception{
        Connection conn = null;
        Class.forName("org.sqlite.JDBC");
        String sql;
        
        try {          
          conn = DriverManager.getConnection(connectionString);
        } 
        catch ( SQLException e ) {

          System.out.println("DB Error: " + e.getMessage());
        }
        //Indsætter fil i databasen
        sql = "INSERT INTO Keeper(Animal_ID,Keeper) VALUES('" + f.getAnimal_ID()+ "','" + f.getKeeper_ID() + "');";
       
        //Udfører fil oprettelsen
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }   
    }
    
    //Henter alle bruger Keeperr
    public ArrayList getAnimalKeeper(int Animal_ID) throws Exception {
        ArrayList<Keeper> allKeeper = getAllKeeper();
        ArrayList<Keeper> AnimalKeeper = new ArrayList();
        
        //Løber alle Keeperr igennem og tester om filidet matcher med bruger idet
        for(int i = 0; allKeeper.size() > i; i++){
           if(allKeeper.get(i).getAnimal_ID() == Animal_ID){
               AnimalKeeper.add(allKeeper.get(i));
           } 
        }
        return AnimalKeeper;
    }
    
    
    
    
    
}
    
    
    
    

