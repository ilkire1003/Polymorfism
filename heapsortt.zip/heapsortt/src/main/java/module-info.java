module org.openjfx.heapsortt {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.base;

    opens org.openjfx.heapsortt to javafx.fxml;
    exports org.openjfx.heapsortt;
}
