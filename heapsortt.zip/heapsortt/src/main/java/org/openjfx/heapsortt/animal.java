/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openjfx.heapsortt;

/**
 *
 * @author elias
 */
public class animal {
    private int id;
    private int amount;
    private String food;
    private String species;
    
    
    public animal(){}
    
    public animal(int id_, int amount_, String food_, String species_){
        id = id_;
        amount = amount_;
        food = food_;
        species = species_;
    
    }
    public int getAID(){
        return id;
    }
    
    public int getAamnt(){
        return amount;
    }
    
    public String getAfood(){
        return food;
    }
    
    public String getAspec(){
        return species;
    }
    
    public void setAID(int id_){
        this.id = id_;
    }
    
    public void setAamnt(int amount_){
        this.amount = amount_;
    }
    
    public void setAfood(String food_){
        this.food = food_;
    }
    
    public void setAspecies(String species_){
        this.species = species_;
    }
    
}
