/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openjfx.heapsortt;

import java.sql.*;
import java.util.ArrayList;

public class Metoder {
    private final String connstr = "jdbc:sqlite:src/list.db";
    
    public ArrayList<animal> getAA() throws SQLException, Exception{
        ArrayList<animal> AA = new ArrayList<>();
        
        Connection conn = null;
        Class.forName("org.sqlite.JDBC");
        
        try {
            conn = DriverManager.getConnection(connstr);
        }
        
        catch (SQLException e){
            System.out.println("DB Error" + e.getMessage());
        }
        
        try{
            Statement stat = conn.createStatement();
            
            ResultSet rs = stat.executeQuery("select * from Animal");
            
            while (rs.next()){
                AA.add(new animal(Integer.parseInt(rs.getString("id")), Integer.parseInt(rs.getString("amount")), rs.getString("food"), rs.getString("species")));
            }
          rs.close();
        }
        
        catch (SQLException e){
            System.out.println("DB Error" + e.getMessage());
        }
      conn.close();
      
      return AA;
    }
    
    public ArrayList<animal> crtA(animal a) throws SQLException, Exception{
        connection conn = null;
        Class.forName("org.sqlite.JDBC");
        String sql;
        
        try{
            conn = DriverManager.getConnection(connstr);
        }
        catch(SQLException e){
            System.out.println("DB Error" + e.getMessage());
        }
        
        sql = "Insert INTO Animal(amount,food,species) VALUES('" + a.getAamnt + "','" + a.getAfood + "','" + a.getAspec + "');)";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)){
            psmt.executeUpdate();
        }   catch(SQLException e){
            System.out.println(e.getMessage());
        }
        
    }
    
    
}
