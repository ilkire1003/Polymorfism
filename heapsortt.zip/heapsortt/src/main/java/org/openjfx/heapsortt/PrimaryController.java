package org.openjfx.heapsortt;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;


public class PrimaryController implements Initializable{

    @FXML
    private Button btn;
    @FXML
    private Button primaryButton;
    @FXML
    private TextField spectxt;
    @FXML
    private TextField foodtxt;
    @FXML
    private TextField amttxt;
    @FXML
    private ListView list;
    private ArrayList<animal> animals;
    @FXML
    private Button IDSort;
    @FXML
    private TableView<?> tblet;
    @FXML
    private TableColumn<?, ?> specolumn;
    @FXML
    private TableColumn<?, ?> foodcolumn;
    @FXML
    private TableColumn<?, ?> amtcolumn;
    @FXML
    private TableColumn<?, ?> IDcolumn;
    
    @Override
    public void initialize (URL url, ResourceBundle rb){
        try {
            loadlstview();
            
        }
        catch(Exception ex){
            Logger.getLogger(PrimaryController.class.getName()).log(Level.SEVERE, null, ex);
            
        }
        
        
        
        
    }
    
    
    
    public void loadlstview() throws Exception{
    Metoder m = new Metoder();
    animals = m.getAA();
    
    for(int i =0;i<animals.size(); i++){
        list.getItems().add(animals.get(i).getAspec());
    }
    }
    
    @FXML
    private void sortedID() throws EXception{
    
    }
    
    @FXML
    private void press() throws SQLException, Exception{
        Metoder m = new Metoder();
        m.crtA(new animal());
        
    }
    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }

    
}
