module org.openjfx.heapsort {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires java.base;

    opens org.openjfx.heapsort to javafx.fxml;
    exports org.openjfx.heapsort;
}
