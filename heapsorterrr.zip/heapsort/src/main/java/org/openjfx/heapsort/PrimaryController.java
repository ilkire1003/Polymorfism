package org.openjfx.heapsort;

import java.io.IOException;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class PrimaryController {
   
    
    
    
    @FXML
    private Button primaryButton;
    @FXML
    private Button but;
    @FXML
    private Label label;
    
    @FXML
    private void handleButtonAction(ActionEvent event)throws SQLException, Exception{
    System.out.println("aaaaaaa");
    label.setText("E");
    Metoder m = new Metoder();
    m.createKeeper(new Keeper(4,1));
    m.getAllKeeper();
    System.out.println(allKeeper());
    }
    
    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }
}
