/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template , choose Tools | Templates
 * and open the template in the editor.
 */
package org.openjfx.heapsort;

/**
 *
 * @author Elias
 */
public class Keeper {
    //Variabler
    public int Keeper_ID;
    public int Animal_ID;
    
    
    //Constructor for klassen Keeper
    public Keeper()
    {}
    
    public Keeper(int _Keeper_ID, int _Animal_ID) {
        Keeper_ID= _Keeper_ID;
        Animal_ID= _Animal_ID;
       
    }

    public int getKeeper_ID() {
        return Keeper_ID;
    }

    public void setKeeper_ID(int _Keeper_ID) {
        this.Keeper_ID =_Keeper_ID;
    }

    public int getAnimal_ID() {
        return Animal_ID;
    }

    public void setAnimal_ID(int _Animal_ID) {
        this.Animal_ID =_Animal_ID;
    }

}

