package org.openjfx.heapsort;

import java.io.IOException;
import java.sql.*;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class PrimaryController {

    @FXML
    private Button btn;
    @FXML
    private Button primaryButton;
    
    @FXML
    private void press() throws SQLException, Exception{
        Metoder m = new Metoder();
        m.getAA();
        System.out.println("aa");
    }
    @FXML
    private void switchToSecondary() throws IOException {
        App.setRoot("secondary");
    }
}
